---
title: Get Guild
category: Guild
order: 2
---

# `getGuild`

```php
$client->guild->getGuild($parameters);
```

## Description



## Parameters


Name | Type | Required | Default
--- | --- | --- | ---
guild.id | snowflake | true | *null*

## Response

Returns the guild object for the given id.

Can Return:

* guild
