---
title: Get Guild Roles
category: Guild
order: 20
---

# `getGuildRoles`

```php
$client->guild->getGuildRoles($parameters);
```

## Description



## Parameters


Name | Type | Required | Default
--- | --- | --- | ---
guild.id | snowflake | true | *null*

## Response

Returns a list of role objects for the guild.

Can Return:

* role
