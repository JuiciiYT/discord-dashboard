---
title: Bulk Delete Messages (Deprecated)
category: Channel
order: 14
---

# `bulkDeleteMessages`

```php
$client->channel->bulkDeleteMessages($parameters);
```

## Description

Same as above, but this endpoint is deprecated.

## Parameters


Name | Type | Required | Default
--- | --- | --- | ---
channel.id | snowflake | true | *null*

## Response

Possibly No Response

