---
title: List Voice Regions
category: Voice
order: 1
---

# `listVoiceRegions`

```php
$client->voice->listVoiceRegions($parameters);
```

## Description



## Parameters

No Parameters

## Response

Returns an array of voice region objects that can be used when creating servers.

Can Return:

* voice region
